let animals = [ 
    {eng: "chicken", aka: ['rooster','cock'], chi: "ji", pin: "ji&#772;", year: 2029, tone: 1},
    {eng: "cow", aka: ['ox'], chi: "niu", pin: "niu&#769;",  year: 2021, tone: 2},
    {eng: "dog", aka: [], chi: "gou", pin: "gou&#780;",  year: 2030, tone:3},
    {eng: "dragon", aka: [], chi: "long", pin: "lo&#769;ng", year: 2024, tone: 2},
    {eng: "goat", aka: ['ram','sheep'], chi: "yang", pin: "ya&#769;ng", year: 2027, tone: 2},
    {eng: "horse", aka: [], chi: "ma", pin: "ma&#780;", year: 2026, tone: 3},
    {eng: "monkey", aka: ["houzi"], chi: 'hou', pin: "ho&#769;uzi", year: 2028, tone: 2},
    {eng: "pig", aka: ["boar"], chi: "zhu", pin: "zhu&#772;", year: 2031, tone: 1},
    {eng: "rabbit", aka: ["tuzi", "hare", "bunny"], chi: "tu", pin: "tu&#768;zi", year: 2023, tone: 4},
    {eng: "rat", aka: ['laoshu'], chi: "shu", pin: "la&#780;oshu&#780;", year: 2020, tone: 3},
    {eng: "snake", aka: ["serpent"], chi: "she", pin: "she&#769;", year: 2025, tone: 2},
    {eng: "tiger", aka: ["laohu"], chi: 'hu', pin: "la&#780;ohu&#780;", year: 2022, tone: 3} 
];